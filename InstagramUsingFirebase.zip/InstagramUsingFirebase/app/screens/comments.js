import React from 'react';
import { TouchableOpacity, TextInput, KeyboardAvoindingView, FlatList, StyleSheet, Text, View, Image } from 'react-native';
import { f, auth, database, storage } from '../../config/config.js';

import UserAuth from '../components/auth.js';

class comments extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            loggedin: false,
            comments_list: []
        }
    }

    checkParams = () => {
        var params = this.props.navigation.state.params;
        if(params){
            if(params.photoId){
                this.setState({
                    photoId: params.photoId
                });

                console.log('Check Params Comments photo Id: '+params.photoId);
                this.fetchComments(params.photoId);
            }

        }
    }

    addCommentToList = (comments_list, data, comment) => {
        console.log(comments_list,data,comment);

       var that = this;
       var commentObj = data[comment];
       database.ref('users').child(commentObj.author).child('username').once('value').then(function(snapshot){

        const exists = (snapshot.val() != null);
        if(exists){
            // add comments to the flat list
            data = snapshot.val();
        }

        console.log('add to comment list user response :'+data);

        
        comments_list.push({
            id: comment,
            comment: commentObj.comment,
            posted: that.timeConvertor(commentObj.posted),
            author: data,
            authorId: commentObj.author
        });  

        that.setState({
            refresh: false,
            loading: false
         });

       }).catch(error => console.log('add comment to list error: '+error));  ;

    }

    fetchComments = (photoId) => {
        // fetch comments here
        console.log('fetching comments: '+photoId);

        var that = this;

        database.ref('comments').child(photoId).orderByChild('posted').once('value').then(function(snapshot){
            const exists = (snapshot.val() != null);
            
            if(exists){
                // add comments to the flat list
                data = snapshot.val();
                var comments_list = that.state.comments_list;                    

                console.log('Comments exists :'+data);

                for(var comment in data){
                    that.addCommentToList(comments_list,data,comment);
                }
                
            }else{

                console.log('Comments not exists');
                // update the state
                
                that.setState({
                    comments_list:[]
                });
            }
            
        }).catch(error => console.log('fetching comments error: '+error));  
    }
    
    s4 = () => {
        return Math.floor((1 + Math.random()) * 0x10000)
        .toString(16)
        .substring(1);
    };


    uniqueId = () => {
        return this.s4() + '-' +  this.s4() + '-' +  this.s4() + '-' +  this.s4() + '-' 
        +  this.s4() + '-'  +  this.s4() + '-'  +  this.s4() + '-'  +  this.s4() ;
    };


    pluralCheck = (s) => {
        if(s==1){
            return ' ago';
        }else{
            return 's ago';
        }
       }
    
       timeConvertor = (timestamp) =>{
        var a = new Date(timestamp*1000);
        var seconds = Math.floor((new Date() - a)/1000);
    
        var interval = Math.floor(seconds / 31536000);
        
        if(interval>1){
            return interval+' year'+this.pluralCheck(interval);
        }
        
        interval = Math.floor(seconds / 2592000);
        if(interval>1){
            return interval+' month'+this.pluralCheck(interval);
        }
    
        interval = Math.floor(seconds / 86400);
        if(interval>1){
            return interval+' day'+this.pluralCheck(interval);
        }
    
        interval = Math.floor(seconds / 3600);
        if(interval>1){
            return interval+' hour'+this.pluralCheck(interval);
        }
    
        interval = Math.floor(seconds / 60);
        if(interval>1){
            return interval+' minute'+this.pluralCheck(interval);
        }
    
        return seconds+' seconds'+this.pluralCheck(seconds);
    
       }
  


    
    componentDidMount = () => {
        // load feed
     var that = this;
     f.auth().onAuthStateChanged(function(user) {
        if(user){
         // logged in
         that.setState({
           loggedin: true
         });
        // console.log('logged in',user);
        }else{
        // logged out
        that.setState({
          loggedin: false
        });
       // console.log('logged out');
        }
     });
     this.checkParams();
    }

    postComment = () => {

        var comment = this.state.comment;

        if(comment != ''){
            alert('comment posting: '+comment);
            // process here
            var imageId = this.state.photoId;
            var userId = f.auth().currentUser.uid;
            var commentId = this.uniqueId();
            var dateTime = Date.now();
            var timestamp = Math.floor(dateTime/1000);

            this.setState({
                comment: ''
            });

            var commentObj = {
                posted: timestamp,
                author: userId,
                comment: comment
            };

            database.ref('/comments/'+imageId+'/'+commentId).set(commentObj);

            // reload comment list
         //   this.reloadCommentList();

        }else{
            alert('Please enter a comment for posting.');
        }
    }
    
    reloadCommentList = () => {

        this.state({
            comments_list: []
        });

        this.fetchComments(this.state.photoId);

    }

    render(){

      return(

        <View style={{flex:1}}>
            <View 
              style={{flexDirection:'row' ,height:60, paddingTop: 25, paddingBottom: 10, backgroundColor: 'white', borderColor: 'lightgrey', borderBottomWidth: 0.5, justifyContent: 'center', justifyContent: 'space-between', alignItems: 'center'} } >
              <TouchableOpacity 
                  style={{width:100}}
                  onPress= {()=> this.props.navigation.goBack()}>
                  <Text style={{fontSize:12, fontWeight:'bold', paddingLeft:10}}>Go Back</Text>
              </TouchableOpacity>    
              <Text> Comments </Text>
              <Text style={{width:100, textAlign:'right', paddingRight:10}}>?</Text>
           </View>

            { this.state.comments_list.length == 0 ? (
                            // no comments show empty state
                    <Text> No comments found </Text>
               ) : (
                <FlatList 
                        refreshing={this.state.refresh}
                        data = {this.state.comments_list}
                        keyExtractor={(item, index) => index.toString()}
                        style={{flex:1, width:480, backgroundColor:'#eeee'}}
                        renderItem={({item, index}) => (
                            <View key={index} style={{width:'100%', overflow:'hidden', marginBottom:5, justifyContent:'space-between', borderBottomWidth: 1, borderColor:'grey'}}>
                              <View style={{padding:5, width:'100%', flexDirection:'row', justifyContent:'space-between'}}>
                                <Text style={{width:'50%'}}>{item.posted}</Text>
                                <TouchableOpacity style={{width:'50%'}}>
                                  <Text >{item.author}</Text>    
                                </TouchableOpacity>                       
                            </View>
                            <View style={{padding:5, width:'100%'}}>
                                <Text style={{color:'grey'}}>{item.comment} </Text>
                            </View>
                            
                            </View>
                        )}    
                        />
                //    <Text>  comments found </Text>
             )}

             { this.state.loggedin == true  ? (
                // <KeyboardAvoindingView behavor="padding" enabled style={{borderTopWidth:1, borderTopColor:'grey', padding:10, marginBottom: 15}}>
                    <View>
                    <Text style={{fontWeight:'bold'}}>Post Comment</Text>
                     <View>
                      <TextInput 
                      editable={true}
                      placeholder={'Enter your comment here...'}
                      onChange={(text) => this.setState({comment: text})}
                      style={{marginVertical:10, height:50, padding:5, borderRadius:3}}
                      ></TextInput>
                     <TouchableOpacity 
                            style={{paddingVertical:10, paddingHorizontal:20, backgroundColor:'blue', borderRadius:5}}
                            onPress={() => this.postComment()}>
                            <Text> Post </Text>
                        </TouchableOpacity>
                    </View>
                    </View>
                  // </KeyboardAvoindingView>
                ) : (
                    <UserAuth message = {'Please login to post a comment'} moveScreen={true}  navigation = {this.props.navigation}/> 
                ) }
        </View>
      )
    }
    



    
    // render(){

    //     return(
    //         <View style={{flex:1}}>
    //                   <View 
    //                   style={{flexDirection:'row' ,height:60, paddingTop: 25, paddingBottom: 10, backgroundColor: 'white', borderColor: 'lightgrey', borderBottomWidth: 0.5, justifyContent: 'center', justifyContent: 'space-between', alignItems: 'center'} } >
    //                    <TouchableOpacity 
    //                         style={{width:100}}
    //                         onPress= {()=> this.props.navigation.goBack()}>
    //                         <Text style={{fontSize:12, fontWeight:'bold', paddingLeft:10}}>Go Back</Text>
    //                     </TouchableOpacity>    
    //                  < Text> Comments </Text>
    //                  <Text style={{width:100, textAlign:'right', paddingRight:10}}>?</Text>
    //                  </View>
    //                 { this.state.comments_list.length == 0 ? (
    //                         // no comments show empty state
    //                         <Text> No comments found </Text>
    //                 ) : (
    //                     <FlatList 
    //                     refreshing={this.state.refresh}
    //                     data = {this.state.comments_list}
    //                     keyExtractor={ (item, index) => index.toString() }
    //                     style={{flex:1, width:480, backgroundColor:'#eeee'}}
    //                     renderItem={({item, index}) => (
    //                         <View key={index} style={{width:'100%', overflow:'hidden', marginBottom:5, justifyContent:'space-between', borderBottomWidth: 1, borderColor:'grey'}}>
    //                           <View style={{padding:5, width:'100%', flexDirection:'row', justifyContent:'space-between'}}>
    //                             <Text style={{width:'50%'}}>{item.posted}</Text>
    //                             <TouchableOpacity style={{width:'50%'}}>
                        
    //                               <Text >{item.author}</Text>    
    //                             </TouchableOpacity>                       
    //                         </View>
    //                         <View style={{padding:5}}>
    //                             <Text>{item.comment} </Text>
    //                         </View>
                            
    //                         </View>
    //                     )}    
    //                     />

    //                   //  <Text> comments found </Text>
    //                 )}

    //             { this.state.loggedin == true  ? (
    //                <KeyboardAvoindingView behavor="padding" enabled style={{borderTopWidth:1, borderTopColor:'grey', padding:10, marginBottom: 15}}>
    //                 <Text style={{fontWeight:'bold'}}>Post Comment</Text>
    //                 <View>
    //                   <TextInput 
    //                   editable={true}
    //                   placeholder={'Enter your comment here...'}
    //                   onChange={(text) => this.setState({comment: text})}
    //                   style={{marginVertical:10, height:50, padding:5, borderColor: 'grey', borderRadius:3, backgroundColor:'white', color: 'black'}}
    //                   ></TextInput>

    //                     <TouchableOpacity 
    //                         style={{paddingVertical:10, paddingHorizontal:20, backgroundColor:'blue', borderRadius:5}}
    //                         onPress={() => this.postComment()}>

    //                         <Text style={{color:'white'}}> Post </Text>
    //                     </TouchableOpacity>
    //                 </View>
    //                </KeyboardAvoindingView>
    //             ) : (
    //                 <View>
    //                 <Text> You are not logged in </Text>
    //                 <Text> Please login to post a comment </Text>
    //                 </View>
    //             ) }
    //         </View>
    //     )

    // }

}

export default comments;