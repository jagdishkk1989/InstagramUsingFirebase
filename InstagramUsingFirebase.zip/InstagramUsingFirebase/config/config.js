import firebase from 'firebase';

const config = {
    
  };
firebase.initializeApp(config);

//firebase.initializeApp(config);

export const f = firebase;
export const database = firebase.database();
export const auth = firebase.auth();
export const storage = firebase.storage();
