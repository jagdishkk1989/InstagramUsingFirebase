import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { createStackNavigator, createBottomTabNavigator, createAppContainer } from 'react-navigation';
import { f, auth, database, storage } from './config/config.js';
import feed from './app/screens/feed.js';
import upload from './app/screens/upload.js';
import profile from './app/screens/profile.js';
import userProfile from './app/screens/userProfile.js';
import comments from './app/screens/comments.js';


const TabStack = createBottomTabNavigator (
    {
      Feed: { screen: feed },
      Upload: { screen: upload },
      Profile: { screen: profile }
    }
  );

const MainStack = createStackNavigator(
    {
      Home: { screen: TabStack },
      User: { screen: userProfile },
      Comments: { screen: comments }
    },
    {
      initalRouteName: 'Home',
      mode: 'modal',
      headerMode: 'none',
    }
  )
const AppContainer  = createAppContainer(MainStack);
  
//export default App;

export default class App extends React.Component {
 
  // commented by jk on 27-12-2018
  // login = async() => {
  //   //Force user to login
  //   try{
  //     let user = await auth.signInWithEmailAndPassword('test@user.com', 'password');
  //   }catch(error){
  //     console.log(error);
  //   }
  // }
  
  constructor(props){
    super(props);
   // this.login(); // commented by jk 27-12-2018
  }
  render() {
    return (
       <AppContainer />
  );
}
}






/*
export default class App extends React.Component {

  constructor(props) {
   super(props);
 
   this.state = {
    loggedin: false
   };
   //this.registerUser('jagdishkk1989@gmail.com','12345678');
  
  var that = this;
  f.auth().onAuthStateChanged(function(user) {
      if(user){
       // logged in
       that.setState({
         loggedin: true
       });
       console.log('logged in',user);
      }else{
      // logged out
      that.setState({
        loggedin: false
      });
      console.log('logged out');
      }
   });


   // set value new value
 /*  database.ref('/refName/childRef/').set("Value!"); */

 // update multiple children

 /*  var updates = {};
  updates['/refName/childRef'] = 'Database';
  updates['/anotherRefName'] = 'Another Value';
  updates['/numbers'] = 5;
  database.ref().update(updates); */

  /* Remove data */
 // database.ref('/numbers').remove();

 // Fetch data
 
//   database.ref('refName').child('childRef').once('value').then(function(snapshot){
//    const exists = (snapshot.val()!=null);
  
//    if(exists) data = snapshot.val();
//    console.log('jk single value', data);
//  }).catch(error => console.log(error)); 

 // fetch and onchange 
/* database.ref('refName').child('childRef').on('value').then(function(snapshot){
  const exists = (snapshot.val()!=null);
 
  if(exists) data = snapshot.val();
  console.log('On value', data);
}).catch(error => console.log(error));


// live update on child add
/* database.ref('refName').on('child_added').then(function(snapshot){
  const exists = (snapshot.val()!=null);
 
  if(exists) data = snapshot.val();
  console.log('On child added', data);
});

/* database.ref('refName').on('child_removed').then(function(snapshot){
  const exists = (snapshot.val()!=null);
 
  if(exists) data = snapshot.val();
  console.log('On child added', data);
}); 



}

  loginUser = async(email, pass) => {
    
    if(email !='' && pass !=''){
      alert('email: '+email +", password: "+pass);
      try{
        let user = await auth.signInWithEmailAndPassword(email,pass)
        console.log(user);
      }catch(error){
        console.log(error);
      }
    }else{
      // if they are empty
      alert('missing email or password');
    }
  }


  signUserOut = ()  => {
    auth.signOut()
   .then(() => {
    console.log('logged out...');
   }
   ).catch((error) => {
    console.log('Error',error);
   });
 }

  async loginWithFacebook (){
    const { type, token } = await Expo.Facebook.logInWithReadPermissionsAsync(
      '375094433230514',
      { permissions: ['email','public_profile'] } 
    );

    if(type == 'success'){
      const credentials = f.auth().FacebookAuthProvider.credential(token);
      f.auth().signInWithCredential(credentials).catch((error) => {
        console.log('Error...',error)
      })
    }


  }

  registerUser = (email, password) => {
    console.log(email, password);
    auth.createUserWithEmailAndPassword(email,password)
    .then((userObj) => console.log(email,password, userObj))
    .catch((error) => console.log('error in login',error));
  }

  render() {
    return (
      <View style={styles.container}>
        <Text>-------</Text>

         {
          
          this.state.loggedin == true ? (
          <View> 
            <TouchableHighlight 
            onPress={() => this.signUserOut()}
            style={{backgroundColor:'red'}}>
             <Text>Log out</Text>
           </TouchableHighlight>
           <Text>Logged in...</Text>
          </View>
          ) : (

            <View>
        
               {
                  this.state.emailloginView  == true ? (
                     <View>
                       <Text> Email: </Text>
                       <TextInput
                        onChangeText={(text) => this.setState({email: text})}
                        value = {this.state.email}
                         />

                        <Text> Password: </Text>
                        <TextInput
                        onChangeText = {(text) => this.setState({pass: text})}
                        secureTextEntry = {true}
                        value = {this.state.pass}
                        />

                        <TouchableHighlight onPress={() => this.loginUser(this.state.email, this.state.pass)}  
                         style={{backgroundColor:'red'}}>
                        <Text style={{color:'white'}}>Login</Text>
                        </TouchableHighlight>
                     </View>                                                                                                                                                                                                               
                  ) : (
                      <View>

                      </View>

                  )

               }

             <TouchableHighlight onPress={() => this.setState({emailloginView: true})}   
               style={{backgroundColor:'green'}}>
               <Text style={{color:'white'}}>Login With Email</Text>
             </TouchableHighlight>
  
             <TouchableHighlight
              onPress={() => this.loginWithFacebook()}
              style={{backgroundColor:'green'}}>
             <Text style={{color:'white'}}>Login With Facebook</Text>
             </TouchableHighlight>

            </View>
            )
          }
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
*/